<!DOCTYPE html>
<html>
<head>
    <title>Test Email</title>
</head>
<body>
    <h2>Hello <?php echo e($user->name); ?>,</h2>

    <p>This is a test email.</p>
</body>
</html>
<?php /**PATH H:\xampp\htdocs\agency2\resources\views/emails/test-mail.blade.php ENDPATH**/ ?>