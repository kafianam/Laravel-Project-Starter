<!DOCTYPE html>
<html>
<head>
    <title>Visa Application PDF</title>
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 14px; }
        .section { margin-bottom: 20px; }
        .label { font-weight: bold; }
        .doc-img { width: 200px; height: auto; margin-top: 10px; }
    </style>
</head>
<body>

    <h2>Visa Application Details</h2>

    <div class="section">
        <p><span class="label">Name:</span> <?php echo e($visaProcessingForm->name); ?></p>
        <p><span class="label">Passport Number:</span> <?php echo e($visaProcessingForm->passport_number); ?></p>
        <p><span class="label">Nationality:</span> <?php echo e($visaProcessingForm->nationality); ?></p>
        <p><span class="label">Travel From:</span> <?php echo e($visaProcessingForm->travel_from); ?></p>
        <p><span class="label">Travel Type:</span> <?php echo e($visaProcessingForm->travel_type); ?></p>
        <p>
    <span class="label">Expected Travel Date:</span>
    <?php echo e($visaProcessingForm->expected_travel_date ? $visaProcessingForm->expected_travel_date->format('Y-m-d') : 'N/A'); ?>

</p>

    </div>

    <div class="section">
        <p><span class="label">Primary Contact:</span> <?php echo e($visaProcessingForm->primary_contact); ?></p>
        <p><span class="label">Emergency Contact:</span> <?php echo e($visaProcessingForm->emergency_contact); ?></p>
        <p><span class="label">Email:</span> <?php echo e($visaProcessingForm->email); ?></p>
    </div>

    <div class="section">
        <p><span class="label">Advance Purchase:</span> 
            <?php echo e(is_array($visaProcessingForm->advance_purchase) ? implode(', ', $visaProcessingForm->advance_purchase) : $visaProcessingForm->advance_purchase); ?>

        </p>
        <p><span class="label">Application Status:</span> <?php echo e($visaProcessingForm->application_status); ?></p>
        <p><span class="label">Payment Status:</span> <?php echo e($visaProcessingForm->payment_status); ?></p>
        <p><span class="label">Payment Method:</span> <?php echo e($visaProcessingForm->payment_method); ?></p>
        <p><span class="label">Payment Date:</span> <?php echo e(optional($visaProcessingForm->payment_date)->format('Y-m-d') ?? 'N/A'); ?></p>



    </div>

    <h3>Uploaded Documents</h3>

    <div class="section">
        <?php if($visaProcessingForm->passport_copy): ?>
            <p><span class="label">Passport Copy:</span></p>
            <img src="<?php echo e(public_path('storage/' . $visaProcessingForm->passport_copy)); ?>" class="doc-img">
        <?php endif; ?>

        <?php if($visaProcessingForm->ticket_copy): ?>
            <p><span class="label">Ticket Copy:</span></p>
            <img src="<?php echo e(public_path('storage/' . $visaProcessingForm->ticket_copy)); ?>" class="doc-img">
        <?php endif; ?>

        <?php if($visaProcessingForm->hotel_booking): ?>
            <p><span class="label">Hotel Booking:</span></p>
            <img src="<?php echo e(public_path('storage/' . $visaProcessingForm->hotel_booking)); ?>" class="doc-img">
        <?php endif; ?>

        <?php if($visaProcessingForm->other_doc): ?>
            <p><span class="label">Other Documents:</span></p>
            <img src="<?php echo e(public_path('storage/' . $visaProcessingForm->other_doc)); ?>" class="doc-img">
        <?php endif; ?>
    </div>

</body>
</html>
<?php /**PATH H:\xampp\htdocs\agency2\resources\views/visa_processing/pdf.blade.php ENDPATH**/ ?>