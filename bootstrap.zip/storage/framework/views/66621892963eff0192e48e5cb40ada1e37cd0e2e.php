<h2>Hello <?php echo e($user->name); ?>,</h2>
<p>Thank you for registering with us as a <?php echo e($user->role); ?>.</p>
<p>We're excited to have you onboard!</p>
<?php /**PATH H:\xampp\htdocs\agency2\resources\views/emails/customer-registered.blade.php ENDPATH**/ ?>