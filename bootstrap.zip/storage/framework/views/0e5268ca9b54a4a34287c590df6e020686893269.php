

<?php $__env->startSection('title', 'Customer Dashboard'); ?>

<?php $__env->startSection('contents'); ?>
    <h2>Welcome to Customer Dashboard</h2>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\agency2\resources\views/customer/dashboard.blade.php ENDPATH**/ ?>