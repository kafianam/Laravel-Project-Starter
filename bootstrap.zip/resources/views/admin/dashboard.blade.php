
@extends('layouts.app')

@section('title', 'Admin Dashboard')

@section('contents')
    <h2>Welcome to Admin Dashboard</h2>
@endsection



