@extends('layouts.app')

@section('content')
    <h1>About Us</h1>
    <p>We are a travel agency offering complete travel solutions...</p>
@endsection
