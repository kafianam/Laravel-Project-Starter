@extends('layouts.app')

@section('title', 'Agent Dashboard')

@section('contents')
    <h2>Welcome to the Agent Dashboard</h2>
@endsection
