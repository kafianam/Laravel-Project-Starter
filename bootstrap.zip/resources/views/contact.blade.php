@extends('layouts.app')

@section('content')
    <h1>Contact Us</h1>
    <p>Email: info@youragency.com</p>
    <p>Phone: +8801XXXXXXXXX</p>
    <p>Address: Your agency address here</p>
@endsection
