<!DOCTYPE html>
<html>
<head>
    <title>Test Email</title>
</head>
<body>
    <h2>Hello {{ $user->name }},</h2>

    <p>This is a test email.</p>
</body>
</html>
