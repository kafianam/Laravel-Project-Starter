<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
</head>
<body>
    <h1 style="text-align: center; margin-top: 100px;">Welcome to our website</h1>
</body>
</html>
