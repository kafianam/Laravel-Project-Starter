@extends('layouts.app')

@section('title', 'Customer Dashboard')

@section('contents')
    <h2>Welcome to Customer Dashboard</h2>
@endsection
