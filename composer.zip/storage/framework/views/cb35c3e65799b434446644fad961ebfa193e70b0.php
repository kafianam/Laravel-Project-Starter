

<?php $__env->startSection('title', 'Edit Service'); ?>



  
<?php $__env->startSection('title', 'Edit Service'); ?>
  
<?php $__env->startSection('contents'); ?>
    <h1 class="mb-0">Edit Product</h1>
    <hr />
    <form action="<?php echo e(route('services.update', $service->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Title</label>
                <input type="text" name="service_name" class="form-control" placeholder="service_name" value="<?php echo e($service->service_name); ?>" >
            </div>
            <div class="col mb-3">
                <label class="form-label">Price</label>
                <input type="text" name="fee" class="form-control" placeholder="Fee" value="<?php echo e($service->fee); ?>" >
            </div>
        </div>
      
        <div class="row">
            <div class="d-grid">
                <button class="btn btn-warning">Update</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\agency2\resources\views/services/edit.blade.php ENDPATH**/ ?>