


<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('contents'); ?>
    <h2>Welcome to Admin Dashboard</h2>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\agency2\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>