

<?php $__env->startSection('content'); ?>
    <h2>Visa Services</h2>
    <a href="<?php echo e(route('admin.services.create')); ?>" class="btn btn-primary">Add New Service</a>
    <table class="table">
        <thead>
            <tr>
                <th>Service Name</th>
                <th>Fee (Tk)</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($service->service_name); ?></td>
                    <td><?php echo e($service->fee); ?></td>
                    <td>
                        <a href="<?php echo e(route('services.edit', $service->id)); ?>" class="btn btn-warning">Edit</a>
                        <form action="<?php echo e(route('services.destroy', $service->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\agency2\resources\views/admin/services/index.blade.php ENDPATH**/ ?>