

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Visa Processing Form Details'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Visa Processing Form Details</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
        <p><strong>Service:</strong> 
    <?php echo e($visaProcessingForm->service->service_name); ?> - <?php echo e($visaProcessingForm->service->fee); ?> TK
            </p>

            <p><strong>Name:</strong> <?php echo e($visaProcessingForm->name); ?></p>
            <p><strong>Passport Number:</strong> <?php echo e($visaProcessingForm->passport_number); ?></p>
            <p><strong>Nationality:</strong> <?php echo e($visaProcessingForm->nationality); ?></p>
            <p><strong>Travel From:</strong> <?php echo e($visaProcessingForm->travel_from); ?></p>
            <p><strong>Travel Type:</strong> <?php echo e($visaProcessingForm->travel_type); ?></p>
            <p><strong>Expected Travel Date:</strong> <?php echo e($visaProcessingForm->expected_travel_date); ?></p>
            <p><strong>Primary Contact:</strong> <?php echo e($visaProcessingForm->primary_contact); ?></p>
            <p><strong>Emergency Contact:</strong> <?php echo e($visaProcessingForm->emergency_contact); ?></p>
            <p><strong>Email:</strong> <?php echo e($visaProcessingForm->email); ?></p>

            <?php if($visaProcessingForm->passport_copy): ?>
                <p><strong>Passport Copy:</strong> <a href="<?php echo e(asset('storage/' . $visaProcessingForm->passport_copy)); ?>" target="_blank">View Passport Copy</a></p>
            <?php else: ?>
                <p><strong>Passport Copy:</strong> Not provided</p>
            <?php endif; ?>

            <?php if($visaProcessingForm->ticket_copy): ?>
                <p><strong>Ticket Copy:</strong> <a href="<?php echo e(asset('storage/' . $visaProcessingForm->ticket_copy)); ?>" target="_blank">View Ticket Copy</a></p>
            <?php else: ?>
                <p><strong>Ticket Copy:</strong> Not provided</p>
            <?php endif; ?>

            <?php if($visaProcessingForm->hotel_booking): ?>
                <p><strong>Hotel Booking:</strong> <a href="<?php echo e(asset('storage/' . $visaProcessingForm->hotel_booking)); ?>" target="_blank">View Hotel Booking</a></p>
            <?php else: ?>
                <p><strong>Hotel Booking:</strong> Not provided</p>
            <?php endif; ?>

            <?php if($visaProcessingForm->other_doc): ?>
                <p><strong>Other Document:</strong> <a href="<?php echo e(asset('storage/' . $visaProcessingForm->other_doc)); ?>" target="_blank">View Other Document</a></p>
            <?php else: ?>
                <p><strong>Other Document:</strong> Not provided</p>
            <?php endif; ?>

           
            <p><strong>Advance Purchase:</strong>
    <?php echo e(is_array($visaProcessingForm->advance_purchase) ? implode(', ', $visaProcessingForm->advance_purchase) : 'Not provided'); ?>

</p>
            <p><strong>Application Status:</strong> <?php echo e($visaProcessingForm->application_status); ?></p>
            <p><strong>Payment Status:</strong> <?php echo e($visaProcessingForm->payment_status); ?></p>
            <p><strong>Payment Method:</strong> <?php echo e($visaProcessingForm->payment_method); ?></p>
            <p><strong>Payment Date:</strong> <?php echo e($visaProcessingForm->payment_date); ?></p>

            <a href="<?php echo e(route('visa_processing.index')); ?>" class="btn btn-secondary">Back to List</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\agency2\resources\views/visa_processing/show.blade.php ENDPATH**/ ?>