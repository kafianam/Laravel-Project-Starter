

  
<?php $__env->startSection('title', 'Create Service'); ?>
  
<?php $__env->startSection('contents'); ?>
    <h1 class="mb-0">Add Service</h1>
    <hr />
    <form action="<?php echo e(route('services.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row mb-3">
            <div class="col">
                <input type="text" name="service_name" class="form-control" placeholder="Serice name">
            </div>
            <div class="col">
                <input type="text" name="fee" class="form-control" placeholder="Fee">
            </div>
        </div>
        
        <div class="row">
            <div class="d-grid">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h2>Add New Visa Service</h2>
    <form action="<?php echo e(route('services.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label>Service Name</label>
            <input type="text" name="service_name" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Fee (Tk)</label>
            <input type="number" name="fee" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-success">Add Service</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\agency2\resources\views/services/create.blade.php ENDPATH**/ ?>