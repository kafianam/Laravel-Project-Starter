<aside class="main-sidebar sidebar-dark-primary elevation-4">
  <!-- Brand Logo -->
  <a href="<?php echo e(route('dashboard')); ?>" class="brand-link">
    <i class="fas fa-laugh-wink brand-image img-circle elevation-3" style="opacity: .8"></i>
    <span class="brand-text font-weight-light">Admin Panel</span>
  </a>

  <!-- Sidebar -->
  <div class="sidebar">
    
    <!-- Sidebar user panel -->
    <div class="user-panel mt-3 pb-3 mb-3 d-flex">
      <div class="image">
        <img src="<?php echo e(asset('path_to_user_image')); ?>" class="img-circle elevation-2" alt="User Image">
      </div>
      <div class="info">
        <a href="/profile" class="d-block">John Doe</a>
      </div>
    </div>

    <!-- Sidebar Menu -->
    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        
        <li class="nav-item">
          <a href="<?php echo e(route('dashboard')); ?>" class="nav-link">
            <i class="nav-icon fas fa-tachometer-alt"></i>
            <p>Dashboard</p>
          </a>
        </li>

        <li class="nav-item">
                    <a href="<?php echo e(url('services')); ?>" class="nav-link">
                        <i class="nav-icon fas fa-box"></i>
                        <p>Services</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(url('visa_processing')); ?>" class="nav-link">
                        <i class="nav-icon fas fa-box"></i>
                        <p>Visa Processing</p>
                    </a>
                </li>

        <li class="nav-item">
          <a href="/profile" class="nav-link">
            <i class="nav-icon fas fa-user"></i>
            <p>Profile</p>
          </a>
        </li>

        <li class="nav-item">
          <a href="<?php echo e(route('logout')); ?>" class="nav-link">
            <i class="nav-icon fas fa-sign-out-alt"></i>
            <p>Logout</p>
          </a>
        </li>

      </ul>
    </nav>
    <!-- /.sidebar-menu -->
  </div>
  <!-- /.sidebar -->
</aside>
<?php /**PATH H:\xampp\htdocs\agency2\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>