
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Visa Applications'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Visa Application List</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card p-3">
        <form method="GET" action="<?php echo e(route('visa_processing.index')); ?>" class="mb-3 d-flex justify-content-between">
            <div>
                <a href="<?php echo e(route('visa_processing.create')); ?>" class="btn btn-primary">Visa Application Form</a>
                <a href="#" class="btn btn-outline-secondary">LOI Request</a>
            </div>
            <div>
                <button class="btn btn-success">Export To Excel</button>
            </div>
        </form>

        <table class="table table-striped table-bordered">
            <thead class="bg-primary text-white">
                <tr>
                    <th>Guest Name</th>
                    <th>Date</th>
                    <th>Travel From</th>
                    <th>Nationality</th>
                    <th>File</th>
                    <th>Status</th>
                    <th>Payment</th>
                    <th>Service</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($form->name); ?><br><?php echo e($form->passport_number); ?></td>
                        <td>
                            Travel: <?php echo e(\Carbon\Carbon::parse($form->expected_travel_date)->format('l, F j, Y')); ?><br>
                            Issue: <?php echo e(\Carbon\Carbon::parse($form->passport_issue_date)->format('l, F j, Y')); ?>

                        </td>
                        <td><?php echo e($form->travel_from); ?></td>
                        <td><?php echo e($form->nationality); ?></td>
                        <td>
                            <?php if($form->passport_copy): ?> ✅ Passport Copy<br> <?php endif; ?>
                            <?php if($form->ticket_copy): ?> ✅ Ticket Copy<br> <?php endif; ?>
                            <?php if($form->hotel_booking): ?> ✅ Hotel Copy<br> <?php endif; ?>
                            <?php if($form->other_doc): ?> ✅ Others Doc<br> <?php endif; ?>
                        </td>
                        <td><?php echo e($form->application_status); ?></td>
                        <td><?php echo e($form->payment_status); ?></td>
                        <td>
                            <?php echo e($form->service->service_name ?? 'N/A'); ?><br>
                            Price: <?php echo e($form->service->fee ?? '0'); ?> TK
                        </td>
                        <td>
                            <a href="<?php echo e(route('visa_processing.show', $form->id)); ?>" class="btn btn-sm btn-primary">Details</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\agency2\resources\views/visa_processing/index.blade.php ENDPATH**/ ?>